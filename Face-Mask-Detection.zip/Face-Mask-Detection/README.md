# Face-Mask-Detection
Detecting face masks using Python, Keras, OpenCV on real video streams

# Face-Mask-Detection
Detecting face masks using Python, Keras, OpenCV on real video streams
# mask_rcnn_test
Use tensorflow object_detection to finetuning a Mask R-CNN model
This Program train to detect the face mask with help of openCV,Keras/TensorFlow, and Deep Learning.
It helps to detect mask on faces in real-time potentially be used to help ensure your safety and the safety of others.

# Service
- Helps to detect face mask kin realTime.
- Works on any device, whether it be Windows, macOS, iOS, Linux.
- Not Collect your personal data.
- Not Contain malvare or any type of virus.
- No ads

## Requirements
- Python3 
- Datasets 
- Zip Extractor

# Libraries
- OpenCV
- Tensorflow
- Keras

# How to Download
- Download zip.
- Unzip "Face-Mask-Detection.zip"
- Run 'Face-Mask-Detection.exe'
